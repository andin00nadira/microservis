package repository;

public class ProdukRepository {
    
}
