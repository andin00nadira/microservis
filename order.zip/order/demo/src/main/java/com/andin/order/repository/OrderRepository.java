package com.andin.order.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.andin.order.model.Order;

public interface OrderRepository extends JpaRepository<Order, Long> {

}