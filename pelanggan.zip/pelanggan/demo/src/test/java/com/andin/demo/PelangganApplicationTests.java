package com.andin.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PelangganApplicationTests {

	@Test
	void contextLoads() {
	}

}
