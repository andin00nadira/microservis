package com.andin.pelanggan.repositoy;

import org.springframework.data.jpa.repository.JpaRepository;
import com.andin.pelanggan.model.pelanggan;

public interface PelangganRepository extends JpaRepository<pelanggan, Long> {

}