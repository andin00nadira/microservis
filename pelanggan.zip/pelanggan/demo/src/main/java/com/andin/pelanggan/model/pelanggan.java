package com.andin.pelanggan.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "pelanggan")
public class pelanggan {


@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;

private String nama;
private String alamat;
private String email;
private String noHp;

public pelanggan() {
}

public Long getId() {
    return id;
}

public void setId(Long id) {
    this.id = id;
}

public String getNama() {
    return nama;
}

public void setNama(String nama) {
    this.nama = nama;
}

public String getAlamat() {
    return alamat;
}

public void setAlamat(String alamat) {
    this.alamat = alamat;
}

public String getEmail() {
    return email;
}

public void setEmail(String email) {
    this.email = email;
}

public String getNoHp() {
    return noHp;
}

public void setNoHp(String noHp) {
    this.noHp = noHp;
}
    

}
