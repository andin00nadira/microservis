package com.andin.pelanggan.service;

import java.util.List;
import com.andin.pelanggan.model.pelanggan;

public interface PelangganService {

List<pelanggan> getAllPelanggan();

pelanggan getPelangganById(Long id);

pelanggan createPelanggan(pelanggan pelanggan);

void deletePelanggan(Long id);

}
