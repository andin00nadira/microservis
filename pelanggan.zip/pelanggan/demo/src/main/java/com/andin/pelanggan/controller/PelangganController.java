package com.andin.pelanggan.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.andin.pelanggan.model.pelanggan;
import com.andin.pelanggan.service.PelangganService;

@RestController
@RequestMapping("/api/pelanggan")
public class PelangganController {


@Autowired
private PelangganService pelangganService;

// GET semua pelanggan
@GetMapping
public List<pelanggan> getAllPelanggan() {
    return pelangganService.getAllPelanggan();
}

// GET pelanggan berdasarkan ID
@GetMapping("/{id}")
public ResponseEntity<pelanggan> getPelangganById(@PathVariable Long id) {
    pelanggan pelanggan = pelangganService.getPelangganById(id);

    if (pelanggan != null) {
        return ResponseEntity.ok(pelanggan);
    } else {
        return ResponseEntity.notFound().build();
    }
}

// POST tambah pelanggan
@PostMapping
public pelanggan createPelanggan(@RequestBody pelanggan pelanggan) {
    return pelangganService.createPelanggan(pelanggan);
}

// DELETE pelanggan
@DeleteMapping("/{id}")
public ResponseEntity<?> deletePelanggan(@PathVariable Long id) 
{
    pelangganService.deletePelanggan(id);
    return ResponseEntity.ok().build();
}

}
